# Data folder

Download and unzip challenge data into this directory, the following files should be available:

* emp_start_end_dates.csv
* employee_roster.csv
* labour_hours_worked.csv
* person_workgroup.csv
* production_data.csv
* safety_events.csv
* site_location.csv
